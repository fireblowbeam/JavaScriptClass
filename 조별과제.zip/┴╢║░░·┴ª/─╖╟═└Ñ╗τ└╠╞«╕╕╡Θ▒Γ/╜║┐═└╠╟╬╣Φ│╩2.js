const slide = document.querySelector(".slide ul");
let isDown = false; // 드래그 상태를 확인하는 변수
let startX; // 드래그 시작 위치 저장 변수
let scrollLeft; // 드래그 시작 시 스크롤 위치 저장 변수

// 슬라이드 전체 크기(width 구하기)
let slideWidth = slide.clientWidth;

// 슬라이드 전체를 선택해 값을 변경해주기 위해 슬라이드 전체 선택하기
const slideItems = document.querySelectorAll(".slide_item");
// 현재 슬라이드 위치가 슬라이드 개수를 넘기지 않게 하기 위한 변수
const maxSlide = slideItems.length;

// 버튼 클릭할 때 마다 현재 슬라이드가 어디인지 알려주기 위한 변수
let currSlide = 1;

// 다음 슬라이드로 이동하는 함수
function nextMove() {
    currSlide++;
    // 마지막 슬라이드 이상으로 넘어가지 않게 하기 위해서
    if (currSlide <= maxSlide) {
        // 슬라이드를 이동시키기 위한 offset 계산
        const offset = slideWidth * (currSlide - 1);
        // 각 슬라이드 아이템의 left에 offset 적용
        slideItems.forEach((i) => {
            i.parentNode.style.transform = `translateX(${-offset}px)`;
        });
    } else {
        currSlide--; // 슬라이드가 마지막일 경우 이동하지 않도록
    }
}

// 이전 슬라이드로 이동하는 함수
function prevMove() {
    currSlide--;
    // 1번째 슬라이드 이하로 넘어가지 않게 하기 위해서
    if (currSlide > 0) {
        // 슬라이드를 이동시키기 위한 offset 계산
        const offset = slideWidth * (currSlide - 1);
        // 각 슬라이드 아이템의 left에 offset 적용
        slideItems.forEach((i) => {
            i.parentNode.style.transform = `translateX(${-offset}px)`;
        });
    } else {
        currSlide++; // 슬라이드가 첫 번째일 경우 이동하지 않도록
    }
}

// 브라우저 화면이 조정될 때 마다 slideWidth를 변경하기 위해
window.addEventListener("resize", () => {
    slideWidth = slide.clientWidth;
});

// 드래그(스와이프) 이벤트를 위한 변수 초기화
let startPoint = 0; // 터치/마우스 드래그 시작 위치 저장 변수
let endPoint = 0; // 터치/마우스 드래그 끝 위치 저장 변수

// PC 클릭 이벤트 (드래그)
slide.addEventListener("mousedown", (e) => {
    isDown = true; // 드래그 상태 시작
    slide.classList.add('active');
    startPoint = e.pageX; // 마우스 드래그 시작 위치 저장
    scrollLeft = slide.scrollLeft; // 드래그 시작 시 스크롤 위치 저장
});

slide.addEventListener("mouseleave", () => {
    isDown = false; // 드래그 상태 종료
    slide.classList.remove('active');
});

slide.addEventListener("mouseup", (e) => {
    isDown = false; // 드래그 상태 종료
    slide.classList.remove('active');
    endPoint = e.pageX; // 마우스 드래그 끝 위치 저장
    if (startPoint < endPoint) {
        // 마우스가 오른쪽으로 드래그 된 경우
        prevMove();
    } else if (startPoint > endPoint) {
        // 마우스가 왼쪽으로 드래그 된 경우
        nextMove();
    }
});

slide.addEventListener("mousemove", (e) => {
    if (!isDown) return; // 드래그 상태가 아니면 함수 종료
    e.preventDefault(); // 기본 동작 방지
    const x = e.pageX - slide.offsetLeft;
    const walk = (x - startPoint) * 3; // 스크롤 속도 조절
    slide.scrollLeft = scrollLeft - walk; // 슬라이드 이동
});
