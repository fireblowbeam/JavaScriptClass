const slide = document.querySelector(".slide ul");
let isDown = false;
let startX;
let scrollLeft;

slide.addEventListener("mousedown", (e) => {
    isDown = true;
    slide.classList.add("active");
    startX = e.pageX - slide.offsetLeft;
    scrollLeft = slide.scrollLeft;
});

slide.addEventListener("mouseleave", () => {
    isDown = false;
    slide.classList.remove("active");
});

slide.addEventListener("mouseup", () => {
    isDown = false;
    slide.classList.remove("active");
});

slide.addEventListener("mousemove", (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - slide.offsetLeft;
    const walk = (x - startX) * 2; // 스크롤 속도 조절
    slide.scrollLeft = scrollLeft - walk;
});

// 모바일 터치 이벤트 (스와이프)
slide.addEventListener("touchstart", (e) => {
    isDown = true; // 터치 시작 시 isDown을 true로 설정
    startX = e.touches[0].pageX - slide.offsetLeft;
    scrollLeft = slide.scrollLeft;
});

slide.addEventListener("touchmove", (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.touches[0].pageX - slide.offsetLeft;
    const walk = (x - startX) * 2; // 스크롤 속도 조절
    slide.scrollLeft = scrollLeft - walk;
});

slide.addEventListener("touchend", () => {
    isDown = false;
});
