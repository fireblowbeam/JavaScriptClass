package food_2;

import java.io.*;
import java.util.ArrayList;

public class Storage {

    private ArrayList<Ingredient> in;

    // 생성자
    public Storage(String filePath) {
        this.in = new ArrayList<>();
        loadIngredients(filePath); // 파일에서 재료를 로드합니다.
    }

    // 파일에서 재료 목록을 불러오는 메서드
    void loadIngredients(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String name = parts[0].trim(); // 공백 제거
                    int amount = Integer.parseInt(parts[1].trim()); // 공백 제거 후 수량 변환
                    in.add(new Ingredient(name, amount));
                    System.out.println("Loaded: " + name + " - " + amount); // 로드된 데이터를 출력
                } else {
                    System.out.println("Invalid line: " + line); // 유효하지 않은 줄을 출력
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    // 재료를 파일에 저장하는 메서드
    void saveIngredients(String filePath) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (Ingredient i : in) {
                bw.write(i.getName() + "," + i.getAmount());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Ingredient> getIn() {
        return in;
    }

    public void setIn(ArrayList<Ingredient> in) {
        this.in = in;
    }

    void fillIngredient(String name, int amount) {
        for (Ingredient i : in) {
            if (i.getName().equals(name)) {
                i.setAmount(i.getAmount() + amount);
            }
        }
    }

    void viewIngredients() {
        for (int i = 0; i < in.size(); i++) {
            System.out.println((i + 1) + ". " + in.get(i).getName() + ", 수량: " + in.get(i).getAmount());
        }
    }
}
