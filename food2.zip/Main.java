package food_2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String filePath = "C:\\Users\\user1\\Documents\\java\\acorn_sub\\src\\res\\data.txt"; // 절대 경로
        Storage storage = new Storage(filePath);

        // Storage 객체 생성, 파일에서 재료 목록을 로드합니다.
//        String filePath = "data.txt";
//        Storage storage = new Storage(filePath);

        // 메뉴 정보 담는 리스트
        ArrayList<Recipe> menuList = new ArrayList<>();

        // 음식 파일에서 읽어오기 (데이터 임시로 넣음)
        ArrayList<String> inList = new ArrayList<>(Arrays.asList("빵", "상추", "오이", "양파", "치킨패티"));
        ArrayList<Integer> amtList = new ArrayList<>(Arrays.asList(2, 1, 5, 1, 1));
        menuList.add(new Recipe("싸이버거", 4600, inList, amtList));
        inList = new ArrayList<>(Arrays.asList("빵", "상추", "오이", "양파", "치즈", "치킨패티"));
        amtList = new ArrayList<>(Arrays.asList(2, 1, 5, 1, 1, 1));
        menuList.add(new Recipe("딥치즈버거", 4800, inList, amtList));

        // 사용자 객체 생성
        System.out.println("이름을 입력하세요");
        String orderer = sc.nextLine();

        User user = new User(orderer);

        while (true) {
            System.out.println("=====================");
            System.out.println("1. 주문하기");
            System.out.println("2. 음식 종류 추가하기");
            System.out.println("3. 재료 창고 확인하기");
            System.out.println("4. 주문내역 확인하기");
            System.out.println("=====================");

            int select = sc.nextInt();
            sc.nextLine();

            switch (select) {
                case 1:

                    System.out.println("메뉴를 선택하세요");

                    for (int i = 0; i < menuList.size(); i++) {
                        System.out.println((i + 1) + ". " + menuList.get(i).getName());
                    }

                    int menu = sc.nextInt() - 1;

                    Recipe menuSelected = menuList.get(menu);

                    // useIngredients: 재료 수량 확인 후 주문 가능하면 true, 불가능하면 false 반환
                    if (menuSelected.useIngredients(storage)) {
                        System.out.println("주문이 확인되었습니다");
                        // 주문 처리 후 재료 수량을 파일에 저장
                        storage.saveIngredients(filePath);
                    } else {
                        System.out.println("재료가 부족합니다");
                    }

                    break;

                case 2:
                    System.out.println("메뉴 이름:");
                    String newName = sc.nextLine();

                    ArrayList<String> newIngredients = new ArrayList<>();
                    ArrayList<Integer> newAmounts = new ArrayList<>();

                    System.out.println("=======================");
                    System.out.println("사용 재료");
                    while (true) {
                        System.out.print("재료 (0 입력 시 종료): ");
                        String newIn = sc.nextLine();
                        if (newIn.equals("0")) {
                            break;
                        }
                        System.out.print("수량: ");
                        int newAmt = sc.nextInt();
                        sc.nextLine();
                        newIngredients.add(newIn);
                        newAmounts.add(newAmt);
                    }
                    System.out.println("=======================");

                    System.out.println("가격: ");
                    int newPrice = sc.nextInt();
                    sc.nextLine();

                    // 입력 정보 바탕으로 메뉴 생성
                    Recipe newRecipe = new Recipe(newName, newPrice, newIngredients, newAmounts);

                    menuList.add(newRecipe);

                    System.out.println("메뉴가 추가되었습니다");

                    break;

                case 3:
                    System.out.println("1. 현재 음식 재료 확인하기");
                    System.out.println("2. 재료 보충하기");

                    int select2 = sc.nextInt();
                    sc.nextLine();

                    switch (select2) {
                        case 1:
                            System.out.println("재료 현황");
                            storage.viewIngredients();
                            break;
                        case 2:
                            storage.viewIngredients();

                            if (storage.getIn().isEmpty()) { // 재료 리스트가 비어 있는지 확인
                                System.out.println("재료가 없습니다.");
                                break;
                            }

                            System.out.println("보충할 재료 선택: ");
                            int select3 = sc.nextInt() - 1;

                            if (select3 < 0 || select3 >= storage.getIn().size()) { // 유효한 인덱스인지 확인
                                System.out.println("잘못된 선택입니다.");
                                break;
                            }

                            System.out.println("수량 입력");
                            int select4 = sc.nextInt();
                            sc.nextLine();

                            storage.fillIngredient(storage.getIn().get(select3).getName(), select4);

                            // 재료 보충 후 파일에 저장
                            storage.saveIngredients(filePath);
                            break;
                    }
                    break;

                case 4:
                    System.out.println("주문 내역:");
                    for (Order order : user.getOrders()) {
                        System.out.println(order.toString());  // order 객체의 toString()을 호출하여 출력
                    }
                    break;
//                case 4:
//                    for (Order order : user.getOrders()) {
//                        System.out.println(order.toString());
//                    }
            }
        }
    }
}
