package food_2;

public interface RecipeI {
	
	public boolean useIngredients(Storage storage);
	
	public void printPrice();

}
