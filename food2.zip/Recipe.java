package food_2;

import java.util.ArrayList;

public class Recipe implements RecipeI {
	
	private String name;
	private int price;
	private ArrayList<String> ingredients;
	private ArrayList<Integer> inAmounts;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public ArrayList<String> getIngredients() {
		return ingredients;
	}

	public void setIngredients(ArrayList<String> ingredients) {
		this.ingredients = ingredients;
	}

	public ArrayList<Integer> getInAmounts() {
		return inAmounts;
	}

	public void setInAmounts(ArrayList<Integer> inAmounts) {
		this.inAmounts = inAmounts;
	}

	public Recipe(String name, int price, ArrayList<String> ingredients, ArrayList<Integer> inAmounts) {
		this.name = name;
		this.price = price;
		this.ingredients = ingredients;
		this.inAmounts = inAmounts;
	}
	
	@Override
	public boolean useIngredients(Storage storage) {
	    // 재료 창고의 모든 재료 검사
	    for (Ingredient ingredient : storage.getIn()) {
	        for (int i = 0; i < ingredients.size(); i++) {
	            if ((ingredient.getName()).equals(ingredients.get(i))) {
	                if (ingredient.getAmount() < inAmounts.get(i)) {
	                    System.out.println(ingredient.getName() + "가(이) 부족합니다. 필요한 수량: " 
	                        + inAmounts.get(i) + ", 현재 수량: " + ingredient.getAmount());
	                    return false;
	                }
	            }
	        }
	    }

	    // 필요한 재료가 충분하다면 재료 수량 차감
	    for (Ingredient ingredient : storage.getIn()) {
	        for (int i = 0; i < ingredients.size(); i++) {
	            if ((ingredient.getName()).equals(ingredients.get(i))) {
	                ingredient.setAmount(ingredient.getAmount() - inAmounts.get(i));
	            }
	        }
	    }
	    
	    return true;
	}



	
	@Override
	public void printPrice() {
		System.out.println(price);
		
	}

}
