package food_2;

public class Order {
	
	private String orderer;
	private String menu;
	private int price;
	private String orderTime;
	
	public String getOrderer() {
		return orderer;
	}

	public void setOrderer(String orderer) {
		this.orderer = orderer;
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(String orderTime) {
		this.orderTime = orderTime;
	}

	public Order(String orderer, String menu, int price, String orderTime) {
		this.orderer = orderer;
		this.menu = menu;
		this.price = price;
		this.orderTime = orderTime;
	}

	@Override
	public String toString() {
		return "주문자: " + orderer + ", 메뉴: " + menu + ", 가격: " + price + ", 주문 시간: " + orderTime;
	}
	
}
