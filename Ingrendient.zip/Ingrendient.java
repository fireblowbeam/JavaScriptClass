package food_test_pr;

public class Ingrendient {
	//멤버 변수: 재료의 이름과 수량을 저장
	private String name;
	private int amount;
	
	//생성자(constructor)주어진 이름과 수량으로 ingredient 객체를 초기화합니다
	public Ingrendient(String name, int amount) {
		 this.name = name;
	        this.amount = amount;
	}
	
	
		//getName()재료의 이름을 반환하는 매서드입니다
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	
	public int getAmount() {
		return amount;
	}
	
	public void setAmount(int amount) {
		this.amount = amount;
	}
}

//작성 순서는 데이터 구조 (Ingredient, Order, Recipe, User) -> 
//인터페이스 (RecipeI) -> 기능 구현 (Storage, Recipe) -> 메인 프로그램 작성 (Main) 순서로 진행됩니다.