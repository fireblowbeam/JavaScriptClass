package food_test_pr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Scanner 객체 생성: 사용자로부터 입력을 받기 위한 객체입니다.
        Scanner sc = new Scanner(System.in);

        // 파일 경로 설정: 재료 정보를 저장한 파일의 절대 경로입니다.
        String filePath = "C:\\Users\\user1\\Documents\\java\\acorn_sub\\src\\res\\data.txt";
        // Storage 객체 생성: 파일에서 재료 목록을 불러와 저장합니다.
        Storage storage = new Storage(filePath);

        // 메뉴 리스트를 저장할 ArrayList 생성
        ArrayList<Recipe> menuList = new ArrayList<>();

        // 기본 메뉴 설정: 임시 데이터로 메뉴를 초기화합니다.
        ArrayList<String> inList = new ArrayList<>(Arrays.asList("빵", "상추", "오이", "양파", "치킨패티"));
        ArrayList<Integer> amtList = new ArrayList<>(Arrays.asList(2, 1, 5, 1, 1));
        menuList.add(new Recipe("싸이버거", 4600, inList, amtList));  // "싸이버거" 메뉴 추가

        inList = new ArrayList<>(Arrays.asList("빵", "상추", "오이", "양파", "치즈", "치킨패티"));
        amtList = new ArrayList<>(Arrays.asList(2, 1, 5, 1, 1, 1));
        menuList.add(new Recipe("딥치즈버거", 4800, inList, amtList));  // "딥치즈버거" 메뉴 추가

        // 사용자 객체 생성: 사용자 이름을 입력받아 User 객체를 생성합니다.
        System.out.println("이름을 입력하세요");
        String orderer = sc.nextLine();

        User user = new User(orderer);

        // 무한 루프: 사용자가 메뉴를 선택할 때까지 프로그램을 계속 실행합니다.
        while (true) {
            // 메뉴 출력
            System.out.println("=====================");
            System.out.println("1. 주문하기");
            System.out.println("2. 음식 종류 추가하기");
            System.out.println("3. 재료 창고 확인하기");
            System.out.println("4. 주문내역 확인하기");
            System.out.println("=====================");

            // 사용자 입력으로 메뉴 선택
            int select = sc.nextInt();
            sc.nextLine();

            // 메뉴 선택에 따른 동작을 결정하는 switch문
            switch (select) {
                case 1:  // 1. 주문하기
                    System.out.println("메뉴를 선택하세요");

                    // 메뉴 목록 출력
                    for (int i = 0; i < menuList.size(); i++) {
                        System.out.println((i + 1) + ". " + menuList.get(i).getName());
                    }

                    // 주문할 메뉴 선택
                    int menu = sc.nextInt() - 1;
                    sc.nextLine();
                    
                    Recipe menuSelected = menuList.get(menu);

                    // 재료가 충분한지 확인 후 주문 처리
                    if (menuSelected.useIngredients(storage)) {
                        System.out.println("주문이 확인되었습니다");
                        // 주문 시간과 메뉴 정보로 Order 객체 생성
                        String orderTime = java.time.LocalDateTime.now().toString();
                        Order newOrder = new Order(user.getName(), menuSelected.getName(), menuSelected.getPrice(), orderTime);

                        // 사용자 주문 리스트에 추가
                        user.getOrders().add(newOrder);

                        // 재료 수량을 파일에 저장
                        storage.saveIngredients(filePath);
                    } else {
                        System.out.println("재료가 부족합니다");
                    }

                    break;

                case 2:  // 2. 음식 종류 추가하기
                    System.out.println("메뉴 이름:");
                    String newName = sc.nextLine();

                    ArrayList<String> newIngredients = new ArrayList<>();
                    ArrayList<Integer> newAmounts = new ArrayList<>();

                    // 새로운 메뉴에 들어갈 재료와 수량을 입력받음
                    System.out.println("=======================");
                    System.out.println("사용 재료");
                    while (true) {
                        System.out.print("재료 (0 입력 시 종료): ");
                        String newIn = sc.nextLine();
                        if (newIn.equals("0")) {
                            break;  // 입력 종료
                        }
                        System.out.print("수량: ");
                        int newAmt = sc.nextInt();
                        sc.nextLine();
                        newIngredients.add(newIn);
                        newAmounts.add(newAmt);
                    }
                    System.out.println("=======================");

                    System.out.println("가격: ");
                    int newPrice = sc.nextInt();
                    sc.nextLine();

                    // 새로운 Recipe 객체를 생성하고 메뉴 리스트에 추가
                    Recipe newRecipe = new Recipe(newName, newPrice, newIngredients, newAmounts);
                    menuList.add(newRecipe);

                    // 디버깅 메시지: 추가된 메뉴와 재료 목록을 출력
                    System.out.println("새로운 메뉴가 추가되었습니다: " + newRecipe.getName());
                    System.out.println("재료 목록:");
                    for (int i = 0; i < newRecipe.getIngredients().size(); i++) {
                        System.out.println(newRecipe.getIngredients().get(i) + " - " + newRecipe.getInAmounts().get(i));
                    }

                    System.out.println("메뉴가 추가되었습니다");

                    break;

                case 3:  // 3. 재료 창고 확인하기
                    System.out.println("1. 현재 음식 재료 확인하기");
                    System.out.println("2. 재료 보충하기");

                    int select2 = sc.nextInt();
                    sc.nextLine();

                    switch (select2) {
                        case 1:  // 현재 재료 목록 확인
                            System.out.println("재료 현황");
                            storage.viewIngredients();
                            break;
                        case 2:  // 재료 보충하기
                            storage.viewIngredients();

                            if (storage.getIn().isEmpty()) { // 재료 리스트가 비어 있는지 확인
                                System.out.println("재료가 없습니다.");
                                break;
                            }

                            System.out.println("보충할 재료 선택: ");
                            int select3 = sc.nextInt() - 1;

                            if (select3 < 0 || select3 >= storage.getIn().size()) { // 유효한 인덱스인지 확인
                                System.out.println("잘못된 선택입니다.");
                                break;
                            }

                            System.out.println("수량 입력");
                            int select4 = sc.nextInt();
                            sc.nextLine();

                            // 선택한 재료 보충
                            storage.fillIngredient(storage.getIn().get(select3).getName(), select4);

                            // 재료 보충 후 파일에 저장
                            storage.saveIngredients(filePath);
                            break;
                    }
                    break;

                case 4:  // 4. 주문내역 확인하기
                    System.out.println("주문 내역:");
                    for (Order order : user.getOrders()) {
                        System.out.println(order.toString());  // order 객체의 toString()을 호출하여 출력
                    }
                    break;
            }
        }
    }
}
