package food_test_pr;

import java.io.*;
import java.util.ArrayList;

import food_test.Ingredient;

public class Storage {

	 private ArrayList<Ingredient> in;
	//멤버 변수: 재료목록을 저장할 ArrayIngredient	private ArrayList<Ingredient> in;
	
	//생성자 Storage 객체를 생성할 때, 재료 목록을 파일에서 불러와 초기화합니다
	public Storage(String filePath) {
		// TODO Auto-generated constructor stub
		this.in = new ArrayList<>(); //재료목록을 담을 리스트 초기화
		loadIngredients(filePath);   //파일에서 재료를 로드하여 리스트에 저장
	}
	
	//파일에서 재료 목록을 불러오는 메서드
	void loadIngredients(String filePath) {
		try(BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String line;
			while((line=br.readLine()) !=null) { //파일에서 한 줄씩 읽어옴
				String[] parts = line.split(","); //각 줄을 쉼표로 분리
				if(parts.length == 2) {
					String name = parts[0].trim(); // 재료 이름의 앞뒤 공백 제거
					int amount = Integer.parseInt(parts[1].trim()); // 재료 수량의 앞뒤 공백 제거 후 정수로 변환
					in.add(new Ingredient(name, amount)); //Ingredient 객체를 생성하여 리스트에 추가
					System.out.println("Loaded:" + name + "_" + amount); //로드된 재료 정보를 출력
				} else {
					System.out.println("Invalid line:" + line); //유효하지 않은 줄을 출력
				}
			}
		} catch (IOException e) {
			e.printStackTrace(); //파일 읽기 중 발생하는 예외를 출력
		}
	}
	
	 public void saveIngredients(String filePath) {
	        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
	            for (Ingredient i : in) {
	                bw.write(i.getName() + "," + i.getAmount());
	                bw.newLine();
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	 
	//재료 목록을 반환하는 Getter 메서드
	public ArrayList<Ingredient> getIn() {
		return in;
	}
	
	//재료 목록을 설정하는 setter 메서드
	public void setIn(ArrayList<Ingredient> in) {
		this.in=in;
	}
	
	//특정 재료의 수량을 증가시키는 메서드
	void fillIngredient(String name, int amount) {
		for(Ingredient i : in) {
			if(i.getName().equals(name)) { //재료 이름이 일치하는지 확인
				i.setAmount(i.getAmount()+amount); //해당 재료의 수량을 증가
			}
		}
	}
	//현재 재료 목록과 수량을 출력하는 메서드
	void viewIngredients() {
		for(int i=0; i<in.size(); i++) {
			System.out.println((i+1) + "." + in.get(i).getName() + ", 수량:" +in.get(i).getAmount());
		}
	}
}
