package food_test_pr;

public interface RecipeI {
	
	//useIngredients 메서드: 재료를 사용하고, 성공 여부를 반환하는 메서드입니다
	//이 메서드는 주어진 Storage 객체에서 필요한 재료의 수량을 차감할 수 있는지 여부를 결정합니다
	//만약 재료가 충분하다면 true를 반환하고 그렇지 않으면 false 반환합니다
	
	public boolean useIngredients(Storage storage);
	
	//printprice 메서드 요리의 가격을 출력하는 메서드입니다
	//이 메서드는 recipe객체에 저장된 가격을 콘솔에 출력합니다
	
	public void printPrice();
}
