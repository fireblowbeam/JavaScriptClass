package food_test_pr;

import java.util.ArrayList;

import food_test.Ingredient;

public class Recipe implements RecipeI {

    // 멤버 변수: 레시피의 이름, 가격, 재료 목록, 재료 수량 목록을 저장합니다.
    private String name;  // 요리의 이름
    private int price;  // 요리의 가격
    private ArrayList<String> ingredients;  // 요리에 필요한 재료들의 이름 목록
    private ArrayList<Integer> inAmounts;  // 각 재료의 필요한 수량 목록

    // Getter 및 Setter 메서드: 각각의 멤버 변수에 접근하고 값을 설정하기 위해 사용합니다.

    // getName(): 요리의 이름을 반환하는 메서드입니다.
    public String getName() {  // 주의: "getNmae" 오타를 "getName"으로 수정해야 합니다.
        return name;
    }

    // setName(): 요리의 이름을 설정하는 메서드입니다.
    public void setName(String name) {
        this.name = name;
    }

    // getPrice(): 요리의 가격을 반환하는 메서드입니다.
    public int getPrice() {
        return price;
    }

    // getIngredients(): 요리에 필요한 재료들의 이름 목록을 반환하는 메서드입니다.
    public ArrayList<String> getIngredients() {
        return ingredients;
    }
    
    public ArrayList<Integer> getInAmounts() {
        return inAmounts;
    }

    // setIngredients(): 요리에 필요한 재료들의 이름 목록을 설정하는 메서드입니다.
    public void setIngredients(ArrayList<String> ingredients) {
        this.ingredients = ingredients;
    }

    // 생성자: Recipe 객체를 생성할 때, 요리의 이름, 가격, 재료 목록, 재료 수량 목록을 초기화합니다.
    public Recipe(String name, int price, ArrayList<String> ingredients, ArrayList<Integer> inAmounts) {
        this.name = name;  // 요리의 이름을 설정
        this.price = price;  // 요리의 가격을 설정
        this.ingredients = ingredients;  // 요리에 필요한 재료 이름 리스트를 설정
        this.inAmounts = inAmounts;  // 각 재료의 필요한 수량 리스트를 설정
    }

    // useIngredients 메서드: 재료 창고에서 필요한 재료와 수량을 사용하고, 충분한지 확인합니다.
    @Override
    public boolean useIngredients(Storage storage) {
        // 필요한 재료와 수량을 임시로 저장할 리스트를 생성
        ArrayList<String> requiredIngredients = new ArrayList<>(ingredients);  // 필요한 재료 이름 리스트 복사
        ArrayList<Integer> requiredAmounts = new ArrayList<>(inAmounts);  // 필요한 재료 수량 리스트 복사
        
        // 재료 창고의 모든 재료를 검사하는 반복문
        for (int i = 0; i < storage.getIn().size(); i++) {
            Ingredient ingredient = storage.getIn().get(i);  // 창고에 있는 재료를 가져옴
            // 각 재료를 필요한 재료와 비교하는 반복문
            for (int j = 0; j < requiredIngredients.size(); j++) {
                System.out.println("비교: 창고 재료=" + ingredient.getName() + " vs 필요 재료=" + requiredIngredients.get(j));
                // 창고에 있는 재료 이름과 필요한 재료 이름이 일치하는지 확인
                if (ingredient.getName().equals(requiredIngredients.get(j))) {
                    System.out.println(ingredient.getName() + " 현재 수량: " + ingredient.getAmount() + ", 필요 수량: " + requiredAmounts.get(j));
                    // 창고에 있는 재료 수량이 필요한 수량보다 적다면
                    if (ingredient.getAmount() < requiredAmounts.get(j)) {
                        // 재료가 부족하다는 메시지를 출력하고 false를 반환하여 재료가 부족함을 알림
                        System.out.println(ingredient.getName() + "가(이) 부족합니다. 필요한 수량: "
                                + requiredAmounts.get(j) + ", 현재 수량: " + 
                        		
                                ingredient.getAmount());
                        return false;  // 재료 부족 시 false 반환
                    }
                }
            }
        }
        
        // 필요한 재료가 충분하다면 재료 수량을 차감하는 반복문
        for (int i = 0; i < storage.getIn().size(); i++) {
            Ingredient ingredient = storage.getIn().get(i);  // 창고에 있는 재료를 가져옴
            for (int j = 0; j < requiredIngredients.size(); j++) {
                // 창고에 있는 재료 이름과 필요한 재료 이름이 일치하는지 확인
                if (ingredient.getName().equals(requiredIngredients.get(j))) {
                    // 재료의 수량을 필요한 만큼 차감
                    ingredient.setAmount(ingredient.getAmount() - requiredAmounts.get(j));
                    System.out.println("사용된 재료: " + ingredient.getName() + ", 남은 수량: " + ingredient.getAmount());
                }
            }
        }
        
        // 모든 재료가 충분히 사용되었으면 true 반환
        return true;  // 변경: 정상적으로 재료 사용 후 true를 반환해야 함
    }

    // printPrice 메서드: 요리의 가격을 출력하는 메서드입니다.
    @Override
    public void printPrice() {
        System.out.println(price);
    }

}
