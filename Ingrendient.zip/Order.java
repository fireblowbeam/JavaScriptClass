package food_test_pr;

public class Order {

	//멤버 변수: 주문자 이름, 메뉴 이름, 가격, 주문 시간을 저장합니다
	private String orderer;
	private String menu;
	private int price;
	private String orderTime; 
	
	public Order(String orderer, String menu, int price, String orderTime) {
		this.orderer=orderer;
		this.menu=menu;
		this.price=price;
		this.orderTime=orderTime;
	}
	
	//주문자의 이름을 반환하는 메서드
	public String getOrderer() {
		return orderer;
	}
	
	public void setOrderer(String orderer) {
		this.orderer = orderer;
	}
	
	public String getMenu() {
		return menu;
	}
	
	public void setMenu(String menu) {
		this.menu = menu;
	}
	
	public int getPrice() {
		return price;
	}
	
	public String getOrderTime() {
		return orderTime;
	}
	
	public void setOrderTime(String orderTime) {
		this.orderTime=orderTime;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "주문자:" + orderer + ", 메뉴:" +menu+ ", 가격" +price+ ", 주문 시간:" +orderTime;
	}
}
