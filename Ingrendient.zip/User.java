package food_test_pr;

import java.util.ArrayList;

public class User {

	//멤버변수: 사용자의 이름과 사용자가 한 주문 목록을 저장
	private String name;
	private ArrayList<Order> orders;
	
	public User(String name) {
		this.name=name;
		this.orders=new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Order> getOrders() {
		return orders;
	}

	public void setOrders(ArrayList<Order> orders) {
		this.orders = orders;
	}
	
	
}
