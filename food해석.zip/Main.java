package food; // 이 클래스가 속한 패키지입니다.

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Scanner;

public class Main { // 프로그램의 진입점인 Main 클래스 정의

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); // 사용자 입력을 받기 위한 Scanner 객체 생성
        
        // 재료 정보 담는 리스트
        ArrayList<Ingredient> in = new ArrayList<>(); // Ingredient 객체를 저장하는 ArrayList 생성
        
        // 재료 창고 파일에서 읽어오기
        // 재료 리스트를 초기화 - 각 재료의 이름과 수량을 정의
        in.add(new Ingredient("빵", 20));
        in.add(new Ingredient("토마토", 5));
        in.add(new Ingredient("베이컨", 7));
        in.add(new Ingredient("오이", 10));
        in.add(new Ingredient("고기패티", 12));
        in.add(new Ingredient("치킨패티", 15));
        in.add(new Ingredient("새우", 13));
        in.add(new Ingredient("양파", 16));
        in.add(new Ingredient("치즈", 13));
        in.add(new Ingredient("상추", 11));
        
        Storage storage = new Storage(in); // 재료 리스트를 포함한 Storage 객체 생성
        
        // 메뉴 정보 담는 리스트
        ArrayList<Recipe> menuList = new ArrayList<>(); // Recipe 객체를 저장하는 ArrayList 생성
        
        // 음식 파일에서 읽어오기
        // 특정 음식(메뉴)을 정의하고 해당 메뉴에 사용될 재료를 리스트로 구성
        ArrayList<String> inList = new ArrayList<>(Arrays.asList("빵", "상추", "오이", "양파", "치킨패티"));
        menuList.add(new Recipe("싸이버거", 4600, inList)); // 싸이버거 메뉴 추가
        inList = new ArrayList<>(Arrays.asList("빵", "상추", "오이", "양파", "치즈", "치킨패티"));
        menuList.add(new Recipe("딥치즈버거", 4800, inList)); // 딥치즈버거 메뉴 추가
        
        // 사용자 객체 생성
        System.out.println("이름을 입력하세요");
        String orderer = sc.nextLine(); // 사용자로부터 이름 입력받음
        
        User user = new User(orderer); // 입력받은 이름을 사용하여 User 객체 생성
        
        while(true) { // 무한 루프 시작 - 사용자가 메뉴를 선택하여 프로그램을 제어할 수 있음
            System.out.println("1. 주문하기");
            System.out.println("2. 음식 종류 추가하기");
            System.out.println("3. 재료 창고 확인하기");
            System.out.println("4. 주문내역 확인하기");
            
            int select = sc.nextInt(); // 메뉴 선택 번호를 입력받음
            sc.nextLine(); // 입력 버퍼 정리
            
            switch(select) { // 사용자의 선택에 따른 작업 수행
            case 1: // 주문하기
                System.out.println("메뉴를 선택하세요");
                
                for(int i=0; i<menuList.size(); i++) {
                    System.out.println((i + 1) + ". " + menuList.get(i).name); // 메뉴 리스트 출력
                }
                
                int menu = sc.nextInt() - 1; // 선택한 메뉴의 인덱스를 저장
                Recipe menuSelected = menuList.get(menu); // 선택한 메뉴의 Recipe 객체 가져오기
                
                // useIngredients: 재료 수량 확인 후 주문 가능하면 true, 불가능하면 false 반환
                if(menuSelected.useIngredients(storage)) {
                    
                    Calendar current = Calendar.getInstance(); // 현재 날짜와 시간을 가져옴
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    String orderTime = sdf.format(current.getTime()); // 주문 시간을 포맷팅하여 문자열로 저장
                    
                    // 주문 객체 생성
                    Order order = new Order(user.name, menuSelected.name, menuSelected.price, orderTime);
                    user.orders.add(order); // 생성된 주문을 사용자의 주문 리스트에 추가
                    System.out.println("주문이 확인되었습니다");
                    System.out.println(order); // 주문 정보 출력
                } else {
                    System.out.println("재료가 부족합니다"); // 재료가 부족할 때 출력되는 메시지
                }
                
                break;
                
            case 2: // 새로운 음식 종류 추가하기
                System.out.println("메뉴 이름: ");
                String newName = sc.nextLine(); // 새 메뉴 이름 입력받음
                System.out.println("사용 재료 (0 입력 시 종료): ");
                ArrayList<String> newIngredients = new ArrayList<>(); // 새로운 재료 리스트 생성
                while(true) {
                    String newIn = sc.nextLine(); // 재료를 하나씩 입력받음
                    if(newIn.equals("0")) {
                        break; // '0'을 입력하면 재료 입력 종료
                    }
                    newIngredients.add(newIn); // 입력받은 재료를 리스트에 추가
                }
                System.out.println("가격: ");
                int newPrice = sc.nextInt(); // 새 메뉴의 가격을 입력받음
                sc.nextLine();
                
                // 입력 정보 바탕으로 메뉴 생성
                Recipe newRecipe = new Recipe(newName, newPrice, newIngredients); // 새로운 Recipe 객체 생성
                
                menuList.add(newRecipe); // 생성된 메뉴를 메뉴 리스트에 추가
                System.out.println("메뉴가 추가되었습니다");
                
                break;
                
            case 3: // 재료 창고 확인하기
                System.out.println("1. 현재 음식 재료 확인하기");
                System.out.println("2. 재료 보충하기");
                
                int select2 = sc.nextInt(); // 재료 창고 확인 혹은 보충 선택
                sc.nextLine();
                
                switch(select2) { // 세부 메뉴 선택
                case 1:
                    System.out.println("재료 현황");
                    storage.viewIngredients(); // 재료 리스트 출력
                    break;
                case 2:
                    storage.viewIngredients(); // 재료 리스트 출력
                    
                    System.out.println("보충할 재료 선택: ");
                    int select3 = sc.nextInt() - 1; // 보충할 재료 선택
                    System.out.println("수량 입력");
                    int select4 = sc.nextInt(); // 보충할 수량 입력
                    sc.nextLine();
                    
                    storage.fillIngredient(in.get(select3).name, select4); // 선택한 재료 보충
                    break;
                }
                
                break;
                
            case 4: // 주문내역 확인하기
                for(Order order : user.orders) {
                    System.out.println(order); // 사용자의 주문 내역 출력
                }
            }
        }
    }
}
