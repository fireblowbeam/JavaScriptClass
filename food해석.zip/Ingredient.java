package food; // 이 클래스가 포함된 패키지 이름을 정의합니다. 이 경우 'food' 패키지에 속해 있습니다.

public class Ingredient { // 'Ingredient' 클래스 정의 시작. 'Ingredient'는 재료를 나타내는 클래스입니다.

    // 필드 선언
    String name;  // 재료의 이름을 저장하는 문자열 변수입니다.
    int amount;   // 재료의 수량을 저장하는 정수형 변수입니다.

    // 생성자
    public Ingredient(String name, int amount) { 
        // 생성자는 객체가 생성될 때 호출되며, 재료의 이름(name)과 수량(amount)을 초기화합니다.
        this.name = name;  // 전달된 name 값을 클래스의 name 필드에 할당합니다.
        this.amount = amount;  // 전달된 amount 값을 클래스의 amount 필드에 할당합니다.
    }

    // 이 클래스는 기본적으로 재료의 이름과 수량을 저장하는 역할을 합니다.
}
