package food; // 이 클래스가 속한 패키지를 정의합니다.

import java.util.ArrayList;

public class Recipe implements RecipeI { 
    // Recipe 클래스 정의 시작. 이 클래스는 특정 요리(메뉴)의 이름, 가격, 그리고 재료 리스트를 관리합니다.
    // RecipeI 인터페이스를 구현합니다.

    // 필드 선언
    String name; // 요리의 이름을 저장하는 문자열 변수입니다.
    int price; // 요리의 가격을 저장하는 정수형 변수입니다.
    ArrayList<String> ingredients; // 요리에 사용되는 재료들의 이름을 저장하는 리스트입니다.

    // 생성자
    public Recipe(String name, int price, ArrayList<String> ingredients) {
        this.name = name; // 전달된 요리 이름을 name 필드에 저장합니다.
        this.price = price; // 전달된 요리 가격을 price 필드에 저장합니다.
        this.ingredients = ingredients; // 전달된 재료 리스트를 ingredients 필드에 저장합니다.
    }

    // RecipeI 인터페이스에서 정의된 메서드를 구현합니다.
    @Override
    public boolean useIngredients(Storage storage) {
        // 이 메서드는 요리를 만들 때 필요한 재료를 창고에서 사용하는 기능을 합니다.
        int count = 0; // 사용할 수 있는 재료 수를 세기 위한 변수입니다.
        
        // 첫 번째 for문: 필요한 재료가 충분한지 확인
        for(Ingredient i : storage.in) {
            for(String name : ingredients) {
                if((i.name).equals(name)) { // 창고에 있는 재료가 레시피에 필요한 재료와 일치하는지 확인합니다.
                    if(i.amount < 1) { // 필요한 재료가 충분하지 않다면, false를 반환하여 주문을 취소합니다.
                        return false;
                    }
                }
            }
        }
        
        // 두 번째 for문: 재료를 실제로 사용 (차감)
        for(Ingredient i : storage.in) {
            for(String name : ingredients) {
                if((i.name).equals(name)) { // 필요한 재료가 있다면
                    i.amount--; // 해당 재료의 수량을 1만큼 줄입니다.
                }
            }
        }
        
        return true; // 모든 재료가 충분히 사용되었다면 true를 반환합니다.
    }

    // 가격 출력 메서드
    @Override
    public void printPrice() {
        System.out.println(price); // 요리의 가격을 출력합니다.
    }

}
