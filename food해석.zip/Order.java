package food; // 이 클래스가 속한 패키지를 정의합니다.

public class Order { // Order 클래스 정의 시작. 이 클래스는 주문 정보를 저장하는 역할을 합니다.
	
    // 필드 선언
    String orderer;   // 주문자의 이름을 저장하는 문자열 변수입니다.
    String menu;      // 주문된 메뉴의 이름을 저장하는 문자열 변수입니다.
    int price;        // 주문된 메뉴의 가격을 저장하는 정수형 변수입니다.
    String orderTime; // 주문이 이루어진 시간을 저장하는 문자열 변수입니다.

    // 생성자
    public Order(String orderer, String menu, int price, String orderTime) {
        // 객체 생성 시 전달된 값을 사용하여 필드를 초기화합니다.
        this.orderer = orderer;         // 전달된 주문자 이름을 orderer 필드에 저장합니다.
        this.menu = menu;               // 전달된 메뉴 이름을 menu 필드에 저장합니다.
        this.price = price;             // 전달된 가격을 price 필드에 저장합니다.
        this.orderTime = orderTime;     // 전달된 주문 시간을 orderTime 필드에 저장합니다.
    }

    // toString 메서드: 객체 정보를 문자열로 반환합니다.
    @Override
    public String toString() {
        // 이 메서드는 Order 객체의 필드 값을 문자열로 반환하며, 이 형식은 객체를 출력할 때 사용됩니다.
        return "주문자: " + orderer + ", 메뉴: " + menu + ", 가격: " + price + ", 주문 시간: " + orderTime;
        // 예: "주문자: John, 메뉴: 싸이버거, 가격: 4600, 주문 시간: 2023-08-29 12:34:56"
    }
}
