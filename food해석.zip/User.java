package food; // 이 클래스가 속한 패키지를 정의합니다.

import java.util.ArrayList;

public class User { // User 클래스 정의 시작. 이 클래스는 사용자의 정보를 관리하는 역할을 합니다.
    
    // 필드 선언
    String name; // 사용자의 이름을 저장하는 문자열 변수입니다.
    ArrayList<Order> orders; // 사용자가 한 주문들을 저장하는 리스트입니다. 이 리스트에는 Order 객체들이 저장됩니다.
    
    // 생성자
    public User(String name) {
        this.name = name; // 전달된 사용자 이름을 name 필드에 저장합니다.
        this.orders = new ArrayList<>(); // 사용자의 주문을 저장할 ArrayList를 초기화합니다.
    }
}
