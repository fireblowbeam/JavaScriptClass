package food; // 이 인터페이스가 속한 패키지를 정의합니다.

public interface RecipeI {
    // 인터페이스는 메서드의 시그니처(선언부)만 정의하며, 구현은 이 인터페이스를 구현하는 클래스에서 합니다.

    /**
     * 이 메서드는 요리(레시피)를 만들기 위해 필요한 재료를 사용(차감)하는 기능을 수행합니다.
     * @param storage 재료를 관리하는 Storage 객체
     * @return 필요한 재료가 충분하면 true, 부족하면 false를 반환합니다.
     */
    public boolean useIngredients(Storage storage);
    
    /**
     * 이 메서드는 요리(레시피)의 가격을 출력하는 기능을 수행합니다.
     */
    public void printPrice();
}
