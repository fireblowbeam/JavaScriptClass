package food; // 이 클래스가 속한 패키지를 정의합니다.

import java.util.ArrayList;

public class Storage { // Storage 클래스 정의 시작. 이 클래스는 재료들을 관리하는 역할을 합니다.

    ArrayList<Ingredient> in; // Ingredient 객체들을 저장하는 리스트입니다. 이 리스트는 창고의 재료 목록을 나타냅니다.
    
    // 생성자
    public Storage(ArrayList<Ingredient> in) {
        this.in = in; // 전달된 재료 목록을 in 필드에 저장합니다.
    }
    
    // 재료를 보충하는 메서드
    void fillIngredient(String name, int amount) {
        // 이 메서드는 특정 재료의 수량을 추가하는 역할을 합니다.
        for(Ingredient i : in) { // 재료 목록을 순회합니다.
            if((i.name).equals(name)) { // 재료의 이름이 일치하는지 확인합니다.
                i.amount += amount; // 일치하면 해당 재료의 수량을 증가시킵니다.
            }
        }
    }
    
    // 현재 창고에 있는 재료 목록을 출력하는 메서드
    void viewIngredients() {
        for(int i=0; i<in.size(); i++) { // 재료 목록을 순회합니다.
            System.out.println((i + 1) + ". " + in.get(i).name + ", 수량: " + in.get(i).amount);
            // 각 재료의 이름과 수량을 출력합니다. 출력 형식은 "1. 재료명, 수량: x"와 같습니다.
        }
    }

}
